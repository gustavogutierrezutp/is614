#!/usr/bin/env python3
"""
Script para convertir un archivo de texto a formato .hex
para inicializar la screen_ram de una FPGA.

Cada carácter se convierte a su código ASCII en hexadecimal.
"""

def txt_to_hex(input_file, output_file, cols=160, rows=50):
    """
    Lee un archivo de texto y genera un archivo .hex con los valores ASCII
    
    Args:
        input_file: Ruta del archivo .txt de entrada
        output_file: Ruta del archivo .hex de salida
        cols: Número de columnas de caracteres (default: 160 para 1280÷8)
        rows: Número de filas de caracteres (default: 50 para 800÷16)
    """
    try:
        # Leer el archivo de texto línea por línea
        with open(input_file, 'r', encoding='utf-8') as f:
            lines = f.readlines()
        
        # Remover '\n' y '\r' de cada línea
        lines = [line.rstrip('\n\r') for line in lines]
        
        # Ajustar el número de líneas (agregar o truncar)
        if len(lines) < rows:
            # Agregar líneas vacías si faltan
            lines.extend([''] * (rows - len(lines)))
        else:
            # Truncar si hay más líneas de las necesarias
            lines = lines[:rows]
        
        # Abrir archivo de salida
        with open(output_file, 'w', encoding='utf-8') as f:
            total_chars = 0
            
            for line in lines:
                # Ajustar cada línea a exactamente 'cols' caracteres
                if len(line) < cols:
                    # Rellenar con espacios si es más corta
                    line = line.ljust(cols)
                else:
                    # Truncar si es más larga
                    line = line[:cols]
                
                # Convertir cada carácter a hexadecimal
                for char in line:
                    ascii_value = ord(char)
                    
                    # Verificar si es un carácter ASCII imprimible
                    if ascii_value < 0x20 or ascii_value > 0x7E:
                        # Caracteres no imprimibles se convierten a espacios
                        f.write('20\n')
                    else:
                        # Escribir el valor hexadecimal (minúsculas, 2 dígitos)
                        f.write(f'{ascii_value:02x}\n')
                    
                    total_chars += 1
        
        print(f"  Conversión exitosa!")
        print(f"  Entrada: {input_file}")
        print(f"  Salida:  {output_file}")
        print(f"  Configuración: {cols} columnas × {rows} filas")
        print(f"  Total de caracteres: {total_chars}")
        print(f"  Líneas procesadas: {len(lines)}")
        
    except FileNotFoundError:
        print(f"  Error: No se encontró el archivo '{input_file}'")
    except Exception as e:
        print(f"  Error: {e}")


def find_signal_positions(input_file, output_file, cols=160):
    """
    Encuentra las posiciones de las X en el archivo de texto
    filtrando automáticamente las etiquetas usando expresiones regulares
    
    Args:
        input_file: Ruta del archivo .txt de entrada
        output_file: Ruta del archivo .sv de salida con las posiciones
        cols: Número de columnas de caracteres
    """
    import re
    
    try:
        with open(input_file, 'r', encoding='utf-8') as f:
            lines = f.readlines()
        
        # Remover '\n' y '\r' de cada línea
        lines = [line.rstrip('\n\r') for line in lines]
        
        # Detectar TODAS las X consecutivas
        all_signals = []
        value_signals = []  # Solo las que parecen valores
        
        for row_idx, line in enumerate(lines):
            col_idx = 0
            while col_idx < len(line):
                if line[col_idx] == 'X':
                    # Contar X consecutivas
                    x_count = 0
                    start_col = col_idx
                    while col_idx < len(line) and line[col_idx] == 'X':
                        x_count += 1
                        col_idx += 1
                    
                    # Obtener contexto (más caracteres para mejor análisis)
                    context_start = max(0, start_col - 20)
                    context_end = min(len(line), col_idx + 10)
                    context_full = line[context_start:context_end]
                    context_before = line[max(0, start_col-5):start_col]
                    context_after = line[col_idx:min(len(line), col_idx+5)]
                    
                    signal_info = {
                        'row': row_idx,
                        'col': start_col,
                        'length': x_count,
                        'context_before': context_before,
                        'context_after': context_after,
                        'context_full': context_full,
                        'is_value': False,
                        'reason': ''
                    }
                    
                    # FILTROS: Determinar si es un VALOR o una ETIQUETA
                    
                    # 1. Si viene después de '=' o ':' seguido de espacio → ES VALOR
                    if re.search(r'[=:]\s*X+$', context_before + 'X'*x_count):
                        signal_info['is_value'] = True
                        signal_info['reason'] = 'Después de = o :'
                    
                    # 2. Si está seguido de ':' → ES ETIQUETA (como "X0:", "X16:")
                    elif re.match(r'^\s*:', context_after):
                        signal_info['is_value'] = False
                        signal_info['reason'] = 'Etiqueta (seguido de :)'
                    
                    # 3. Si es "X" seguido de números y ":" → ES ETIQUETA (como "X10:", "X31:")
                    elif re.search(r'X\d+\s*:', context_full):
                        signal_info['is_value'] = False
                        signal_info['reason'] = 'Etiqueta X[0-31]'
                    
                    # 4. Si está rodeado de espacios y es largo (≥3) → Probablemente VALOR
                    elif x_count >= 3 and context_before.endswith(' ') and (not context_after or context_after[0] == ' '):
                        signal_info['is_value'] = True
                        signal_info['reason'] = 'Valor entre espacios'
                    
                    # 5. Si es muy largo (≥7) → Probablemente VALOR hexadecimal
                    elif x_count >= 7:
                        signal_info['is_value'] = True
                        signal_info['reason'] = 'Valor largo (≥7 dígitos)'
                    
                    # 6. Caso por defecto para señales cortas
                    else:
                        # Si tiene longitud útil (1-6) y no es etiqueta obvia
                        if not re.search(r'X\d', context_full):
                            signal_info['is_value'] = True
                            signal_info['reason'] = 'Señal corta (no etiqueta)'
                    
                    all_signals.append(signal_info)
                    if signal_info['is_value']:
                        value_signals.append(signal_info)
                else:
                    col_idx += 1
        
        # Generar archivo con análisis completo
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write("// Auto-generado por txt_to_hex.py\n")
            f.write("// Análisis automático con filtrado inteligente\n\n")
            f.write(f"// Total detectado: {len(all_signals)} patrones\n")
            f.write(f"// Valores (filtrados): {len(value_signals)} señales\n")
            f.write(f"// Etiquetas (ignoradas): {len(all_signals) - len(value_signals)}\n\n")
            
            # Mostrar señales FILTRADAS (valores)
            f.write("// ========== SEÑALES DE VALOR (FILTRADAS) ==========\n")
            for idx, sig in enumerate(value_signals):
                ctx = sig['context_full'].replace('\t', ' ')
                f.write(f"// [{idx:2d}] Fila {sig['row']:2d}, Col {sig['col']:3d}, Len {sig['length']} | "
                       f"{sig['reason']:25s} | {ctx}\n")
            
            # Array listo para copiar (SOLO VALORES)
            f.write("\n\n// ========== CÓDIGO PARA write_vga.sv ==========\n")
            f.write(f"// parameter NUM_SIGNALS = {len(value_signals)};\n\n")
            f.write("// Array SIGNAL_CONFIGS (valores filtrados):\n")
            f.write("/*\n")
            for idx, sig in enumerate(value_signals):
                f.write(f"  '{{6'd{sig['row']:2d}, 8'd{sig['col']:3d}, 5'd{sig['length']}}}")
                if idx < len(value_signals) - 1:
                    f.write(f",  // {idx:2d}\n")
                else:
                    f.write(f"   // {idx:2d}\n")
            f.write("*/\n")
            
            # Sección de debug: mostrar lo que se ignoró
            f.write("\n\n// ========== DEBUG: ETIQUETAS IGNORADAS ==========\n")
            ignored = [s for s in all_signals if not s['is_value']]
            for sig in ignored:
                ctx = sig['context_full'].replace('\t', ' ')
                f.write(f"// IGNORADO: Fila {sig['row']:2d}, Col {sig['col']:3d}, Len {sig['length']} | "
                       f"{sig['reason']:25s} | {ctx}\n")
        
        # Reporte en consola
        print(f"\n  ✓ Análisis completado con filtrado inteligente!")
        print(f"  Total detectado: {len(all_signals)} patrones de 'X'")
        print(f"  Valores identificados: {len(value_signals)} señales")
        print(f"  Etiquetas ignoradas: {len(all_signals) - len(value_signals)}")
        print(f"\n  Revisa '{output_file}' para:")
        print(f"    • Ver señales filtradas con contexto")
        print(f"    • Copiar array listo para write_vga.sv")
        print(f"    • Verificar qué se ignoró en sección DEBUG")
        
        return value_signals
        
    except FileNotFoundError:
        print(f"  ✗ Error: No se encontró el archivo '{input_file}'")
        return []
    except Exception as e:
        print(f"  ✗ Error: {e}")
        import traceback
        traceback.print_exc()
        return []


if __name__ == "__main__":
    # Archivos de entrada y salida
    input_file = "screen.txt"
    output_hex = "screen_ram.hex"
    output_positions = "signal_positions.sv"
    
    print("=" * 60)
    print("Conversor TXT → HEX para Screen RAM")
    print("=" * 60)
    
    # Realizar la conversión a HEX
    txt_to_hex(input_file, output_hex)
    
    print("\n" + "=" * 60)
    print("Extractor de Posiciones de Señales")
    print("=" * 60)
    
    # Extraer posiciones de las señales
    find_signal_positions(input_file, output_positions)
