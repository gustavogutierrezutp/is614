from equivalencias import *      
from bitstring import Bits       
import json, re                  

# -------------------------------
#  LECTURA DE INSTRUCCIONES
# -------------------------------

def obtener_info_instrucciones(archivo):
    """Abre un archivo JSON y lo devuelve como diccionario."""
    with open(archivo, "r") as archivo:
        return json.load(archivo)

# Diccionario con las pseudoinstrucciones cargadas desde archivo externo
PSEUDOINSTRUCCIONES: dict = obtener_info_instrucciones(ARCHIVO_INSTRUCCIONES_PSEUDO)


def leer_archivo(archivo):
    """Lee el contenido completo de un archivo de texto en UTF-8."""
    with open(archivo, "r", encoding="utf-8") as archivo:
        return archivo.read()


# -------------------------------
#  CONVERSIONES BINARIAS
# -------------------------------

def numero_a_binario(numero: int | str, longitud=4, con_signo=True):
    """
    Convierte un número (entero o hexadecimal en string) a binario.
    - longitud: cantidad de bits de salida.
    - con_signo: si True, usa complemento a dos para negativos.
    """
    if isinstance(numero, str) and "0x" in numero:   # Ejemplo: "0xF"
        numero = int(numero, 16)
    binario = int(numero).to_bytes(5, signed=con_signo)
    return ''.join(format(byte, '08b') for byte in binario)[-longitud:]


def binario_a_decimal(binario: str):
    """Convierte un string binario en entero (con signo si aplica)."""
    return Bits(bin=binario).int


# -------------------------------
#  MANEJO DE REGISTROS
# -------------------------------

def obtener_numero(reg):
    """Extrae el número de un registro en formato string (ej: 'x5', 't0')."""
    match = re.search(r'\d+', reg)
    return int(match.group()) if match else None


def separar_lineas(text: str):
    """
    Limpia y separa un bloque de texto en líneas útiles.
    - Elimina espacios iniciales/finales.
    - Elimina comentarios después de '#'.
    - Descarta líneas vacías.
    """
    return [
        linea.strip().split("#")[0]
        for linea in text.splitlines()
        if linea.strip()
    ]


def registro(reg, linea=None):
    """
    Convierte un registro a su número binario de 5 bits.
    Valida que esté dentro del rango permitido (x0..x31).
    """
    if "x" not in reg:   # No es numérico, buscar en equivalencias
        x_reg = Equivalencias.get(reg)
        if not x_reg:
            raise ValueError(f"Registro inválido: {reg} en la línea {linea if linea is not None else '?'}")
        reg = x_reg

    num_reg = obtener_numero(reg)
    if num_reg is None:
        raise ValueError(f"Registro inválido: {reg} en la línea {linea if linea is not None else '?'}")

    if not (0 <= num_reg <= 31):
        raise ValueError(f"Registro fuera de rango: {reg} - solo x0..x31 - en la línea {linea if linea is not None else '?'}")

    return numero_a_binario(num_reg, 5)


# -------------------------------
#  ETIQUETAS Y PSEUDOINSTRUCCIONES
# -------------------------------

DATOS = {}   # Diccionario de etiquetas de datos


def distancia_etiqueta(etiqueta, linea):
    """
    Calcula la dirección/offset de una etiqueta.
    - Si está en .text → devuelve offset relativo en bytes.
    - Si está en .data → devuelve dirección absoluta.
    """
    etiqueta = etiqueta.strip()
    if etiqueta.endswith(":"):
        etiqueta = etiqueta[:-1]

    if etiqueta in ETIQUETAS:   # Caso .text
        linea_etiqueta = ETIQUETAS.get(etiqueta)
        if isinstance(linea_etiqueta, int):
            return (linea_etiqueta - linea) * 4
        else:
            raise ValueError(f"Etiqueta inválida en .text: {etiqueta}")
    if etiqueta in DATOS:       # Caso .data
        return DATOS[etiqueta]

    raise ValueError(f"Etiqueta inválida: '{etiqueta}' o duplicada -->línea actual={linea}")


def etiqueta_valida(etiqueta):
    """Verifica si una cadena cumple el formato de etiqueta."""
    match = re.findall(r"\s*[a-zA-Z_][a-zA-Z0-9_]*\s*\(.*\):|\s*[a-zA-Z_.][a-zA-Z0-9_]*:", etiqueta)
    return match[0] if match else None


def pseudo(instruccion):
    """
    Determina si una instrucción es pseudoinstrucción.
    Devuelve:
    - dict con los campos capturados.
    - equivalencia real.
    """
    for regular_pseudo, equivalencia in PSEUDOINSTRUCCIONES.items():
        match = re.match(fr"{regular_pseudo}", instruccion)
        if match:
            return match.groupdict(), equivalencia
    return False, False


def inm_de_12Bits(n) -> bool:
    """Verifica si un inmediato cabe en 12 bits con signo."""
    try:
        n_int = int(str(n), 0)
    except Exception:
        return False
    return -2048 <= n_int <= 2047


def cortar_inmediato(inmediato: str, linea=None):
    """
    Procesa un inmediato o etiqueta.
    - Si cabe en 12 bits → devuelve solo parte_baja.
    - Si no cabe → devuelve parte_alta y parte_baja.
    """
    try:
        imm_val = distancia_etiqueta(inmediato, linea)
    except ValueError:
        try:
            imm_val = int(str(inmediato), 0)
        except Exception:
            if etiqueta_valida(inmediato):
                return None
            raise ValueError(f"Inmediato inválido: {inmediato} en la línea {linea}")

    if -2048 <= imm_val <= 2047:
        return {"parte_alta": 0, "parte_baja": imm_val & 0xFFF}

    parte_baja = imm_val & 0xFFF
    parte_alta = (imm_val + (1 << 32)) >> 12
    parte_alta &= (1 << 20) - 1
    return {"parte_alta": parte_alta, "parte_baja": parte_baja}


# -------------------------------
#  IMPLEMENTACIÓN DE .DATA
# -------------------------------

DATA_BASE = 0x10010000   # Dirección base del segmento .data
DATA_MEM = bytearray()   # Buffer que guarda los datos binarios


def alinear_datos(alignment: int):
    """Alinea DATA_MEM al múltiplo de 'alignment' bytes rellenando con 0."""
    while len(DATA_MEM) % alignment != 0:
        DATA_MEM.append(0)


def agregar_bytes_de_datos(b: bytes):
    """Agrega bytes al segmento .data y devuelve el offset inicial."""
    offset = len(DATA_MEM)
    DATA_MEM.extend(b)
    return offset


def añadir_word(value: int, linea: int = 0):
    """
    Añade un entero de 32 bits (word) en formato little endian.
    Valida que el valor esté dentro del rango de 32 bits con signo.
    """
    if not (-2**31 <= value <= 2**31 - 1):
        raise ValueError(
            f"Error en línea {linea}: valor fuera de rango para .word "
            f"Valor recibido: {value}, esperado entre {-2**31} y {2**31 - 1}"
        )
    return agregar_bytes_de_datos(int(value).to_bytes(4, "little", signed=True))



def añadir_half(value: int, linea: int = 0):
    """
    Añade un entero de 16 bits (halfword) en formato little endian.
    Valida que el valor esté dentro del rango de 16 bits con signo.
    """
    if not (-2**15 <= value <= 2**15 - 1):
        raise ValueError(
            f"Error en línea {linea}: valor fuera de rango para .half "
            f"Valor recibido: {value}, esperado entre {-2**15} y {2**15 - 1}"
        )
    return agregar_bytes_de_datos(int(value).to_bytes(2, "little", signed=True))



def añadir_byte(value: int, linea: int = 0):
    """
    Añade un entero de 8 bits (byte) en formato little endian.
    Valida que el valor esté dentro del rango de 8 bits con signo.
    """
    if not (-2**7 <= value <= 2**7 - 1):
        raise ValueError(
            f"Error en línea {linea}: valor fuera de rango para .byte "
            f"Valor recibido: {value}, esperado entre {-2**7} y {2**7 - 1}"
        )
    return agregar_bytes_de_datos(int(value).to_bytes(1, "little", signed=True))

