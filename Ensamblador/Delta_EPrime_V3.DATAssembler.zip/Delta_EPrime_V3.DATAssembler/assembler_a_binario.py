import re
from equivalencias import *
from assembler_utilitarios import *
from compilacion_instrucciones import *
from manejador_archivos import *
from validar_instrucciones import *

# =========================
# Cargar info de instrucciones
# =========================
# INFO contendrá un diccionario con la definición de TODAS las instrucciones
# (formato, campos, regex asociada, etc.) a partir de un JSON.
INFO: dict = obtener_info_instrucciones(archivo=ARCHIVO_INSTRUCCIONES)


# =========================
# Utilidades de instrucción
# =========================
def tipo_instruccion(instruccion):
    """
    Devuelve el tipo de la instrucción (R, I, J, etc.)
    según dónde esté definida en INFO.
    """
    for tipo, datos in INFO.items():
        if instruccion in datos["inst"].keys():
            return tipo


def obtener_info(instruccion: str, linea=None):
    """
    Devuelve (info, tipo) de la instrucción o etiqueta.
    Si no corresponde a una instrucción válida, revisa si es una etiqueta.
    """
    inst = obtener_nombre(instruccion.strip())
    tipo_inst = tipo_instruccion(inst)
    if tipo_inst:
        return INFO[tipo_inst], tipo_inst
    else:
        etiqueta = etiqueta_valida(inst)
        if not etiqueta:
            raise ValueError(f"Instrucción inválida: {instruccion} --> Línea: {linea}")
    return None, None


def obtener_nombre(instruccion: str):
    """
    Devuelve la primera palabra (el nombre de la instrucción).
    Ej: 'add x1, x2, x3' -> 'add'
    """
    return instruccion.split(" ")[0]


def expresion_regular(instrucciones: list, expresion: str):
    """
    Construye la regex para tokenizar instrucciones.
    Reemplaza 'expr' con la lista de instrucciones posibles.
    """
    instrucciones_unidas = "|".join(instrucciones)
    return expresion.replace("expr", f"?P<operacion>{instrucciones_unidas}")


def tokenizar(instruccion: str, expresion: str):
    """
    Intenta aplicar la regex a la instrucción y devuelve los tokens como diccionario.
    Si no coincide, lanza un error.
    """
    patron = re.compile(fr"{expresion}")
    coincidencia = patron.match(instruccion)
    if coincidencia:
        return coincidencia.groupdict()
    else:
        raise ValueError(f"Instrucción inválida: {instruccion} por : Falta de inmediato | Constante representable en 12 bits")


# =========================
# Pseudoinstrucciones
# =========================
def compilar_pseudo(equivalencia, coincidencias: dict, linea: str | int):
    """
    Expande pseudoinstrucciones:
    - Si es una cadena -> la reemplaza directamente.
    - Si es una lista -> maneja el caso especial de símbolos inmediatos.
    """
    if isinstance(equivalencia, str):
        return [equivalencia.format(**coincidencias)]
    elif isinstance(equivalencia, list):
        equivalencia = "|".join(equivalencia)
        simbolos = cortar_inmediato(coincidencias["symbol"], linea)
        if simbolos is None:
            return None
        coincidencias.update(simbolos)
        del coincidencias["symbol"]
        equivalencia = equivalencia.format(**coincidencias)
        if simbolos["symbol1"] == 0:
            return equivalencia.split("|")[1:]
        return equivalencia.split("|")
    else:
        raise TypeError(f"Tipo no soportado: {type(equivalencia)}")


def instruccion_especial(instruccion, info_instrucciones):
    """
    Intenta reconocer instrucciones que tienen regex distintas
    (casos especiales como 'lw', 'sw', etc.)
    """
    for i, info in enumerate(info_instrucciones):
        re_exp = expresion_regular(info["inst"].keys(), info["re"])
        try:
            token_instruccion = tokenizar(instruccion, re_exp)
            return token_instruccion, i
        except ValueError: 
            pass


def compilar_instruccion(token_instruccion, info, tipo_inst, linea):
    """
    Compila una instrucción dependiendo de su tipo (R, I, B, S, U, J, etc.)
    """
    if tipo_inst == "R":
        return inst_r(token_instruccion, info, linea)
    elif tipo_inst in ("I1", "I2", "I3"):
        return inst_i(token_instruccion, info, linea)
    elif tipo_inst == "B":
        return inst_b(token_instruccion, info, linea)
    elif tipo_inst == "S":
        return inst_s(token_instruccion, info, linea)
    elif tipo_inst == "U":
        return inst_u(token_instruccion, info, linea)
    elif tipo_inst == "J":
        return inst_j(token_instruccion, info, linea)
    elif tipo_inst == "SO":
        return info["inst"][token_instruccion["operacion"]]


def gestor_instrucciones(instruccion, linea):
    """
    Orquesta el proceso de traducción:
    - Obtiene info y tipo de instrucción.
    - Tokeniza.
    - Llama al compilador adecuado.
    - LSa devuelve a Binario
    """
    info, tipo_inst = obtener_info(instruccion, linea)
    if info:
        if isinstance(info, list):
            token_instruccion, i = instruccion_especial(instruccion, info)
            info = info[i]
        else:
            re_exp = expresion_regular(info["inst"].keys(), info["re"])
            token_instruccion = tokenizar(instruccion, re_exp)
        return compilar_instruccion(token_instruccion, info, tipo_inst, linea)


# =========================
# Manejo de etiquetas
# =========================
def sumar_etiquetas(linea: int):
    """Ajusta las posiciones de etiquetas cuando se insertan pseudoinstrucciones."""
    for etiqueta in ETIQUETAS.keys():
        if ETIQUETAS.get(etiqueta) > linea:
            ETIQUETAS[etiqueta] += 1


def limpiar_instrucciones(instrucciones: str):
    """
    Elimina comentarios y espacios en blanco de un bloque de código ASM.
    """
    resultado = re.sub(r'#.*$', '', instrucciones, flags=re.MULTILINE)
    resultado = re.sub(r'\s*$', '', resultado, flags=re.MULTILINE)
    resultado = re.sub(r'^\s*', '', resultado, flags=re.MULTILINE)
    return resultado


def procesar_pseudoinstrucciones(instrucciones: list, i=0, pseudo_inst=[]):
    """
    Expande todas las pseudoinstrucciones en una lista de instrucciones ASM real.
    - Recorre la lista.
    - Si encuentra pseudo → llama a compilar_pseudo.
    - Reemplaza la pseudo con las instrucciones reales.
    - Ajusta etiquetas con sumar_etiquetas.
    """
    for instruction in instrucciones:
        match, equivalencia = pseudo(instruction)
        if isinstance(match, dict):
            inst = compilar_pseudo(equivalencia, match, i)
            if inst is None:
                instrucciones.remove(instruction)
                inst = compilar_instruccion(equivalencia, match, i)
            pseudo_inst += inst
            if len(inst) > 1:
                sumar_etiquetas(i)
                i += 1
        else:
            pseudo_inst.append(instruction)
        i += 1
    return pseudo_inst


def obtener_todas_etiquetas(instrucciones: list, i=0, pseudo_inst=[]):
    """
    Escanea todas las etiquetas del código ASM (.text) y las guarda en ETIQUETAS.
    Si encuentra una repetida, lanza error con la línea exacta.
    """
    for instruction in instrucciones.copy():
        label = etiqueta_valida(instruction)
        if label:
            nombre = label.replace(":", "")
            if nombre in ETIQUETAS:
                raise ValueError(f"Etiqueta repetida en .text: {nombre} (línea {i})")
            ETIQUETAS[nombre] = i
            i -= 1
            instrucciones.remove(instruction)
        else:
            pseudo_inst.append(instruction)
        i += 1
    return pseudo_inst

# =========================
# DIRECTIVA .DATA
# =========================
def procesar_segmentos_y_datos(texto_completo: str):
    """
    Procesa las directivas .data y llena:
    - DATA_MEM: la memoria de datos.
    - ETIQUETAS: posiciones de variables.
    Devuelve únicamente las líneas de la sección .text limpias.
    """
    lines = texto_completo.splitlines()
    segmento_actual = "text"
    text_lines = []

    for num_linea, raw in enumerate(lines, start=1):
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith(".data"):
            segmento_actual = "data"
            continue
        if line.startswith(".text"):
            segmento_actual = "text"
            continue

        if segmento_actual == "data":
            # Asignar etiquetas a variables
            if ":" in line:
                left, right = line.split(":", 1)
                label = left.strip()
                if label in ETIQUETAS:
                    raise ValueError(f"Etiqueta repetida en .data: {label} (línea {num_linea})")
                ETIQUETAS[label] = DATA_BASE + len(DATA_MEM)
                line = right.strip()
                if not line:
                    continue

            # Procesar directivas
            if line.startswith(".word"):
                args = [a.strip() for a in line[len(".word"):].split(",") if a.strip()]
                for a in args:
                    añadir_word(int(a, 0))
            elif line.startswith(".half"):
                args = [a.strip() for a in line[len(".half"):].split(",") if a.strip()]
                for a in args:
                    añadir_half(int(a, 0))
            elif line.startswith(".byte"):
                args = [a.strip() for a in line[len(".byte"):].split(",") if a.strip()]
                for a in args:
                    añadir_byte(int(a, 0))
            else:
                raise ValueError(f"Directiva .data desconocida: {line} (línea {num_linea})")
        else:
            text_lines.append(line)

    return text_lines

# =========================
# MAIN
# =========================
def main(file):
    """
    Flujo principal del ensamblador:
    1) Lee el archivo .asm
    2) Limpia comentarios
    3) Procesa .data y .text
    4) Expande pseudoinstrucciones
    5) Detecta etiquetas
    6) Ensambla instrucciones a binario
    7) Guarda todas las salidas (.bin, .hex, etc.)
    """
    archivo_instrucciones = leer_archivo(file)
    print(archivo_instrucciones)
    archivo_instrucciones = limpiar_instrucciones(archivo_instrucciones)
    print(archivo_instrucciones)
    # 1) Procesar segmentos (.data y .text)
    instrucciones_text = procesar_segmentos_y_datos(archivo_instrucciones)
    # 2) Expandir pseudoinstrucciones
    instrucciones_text = procesar_pseudoinstrucciones(instrucciones_text)
  
    # 3) Obtener etiquetas en texto
    instrucciones_text = obtener_todas_etiquetas(instrucciones_text)
    print(instrucciones_text)
    # 4) Ensamblar instrucciones
    for line_index, instruction in enumerate(instrucciones_text):
        binario = gestor_instrucciones(instruction, line_index)
        if binario:
            INSTRUCCIONES_BINARIO.append(binario)

    # Guardar salidas
    guardar_data_bin("./output/directiva_data.bin")
    guardar_binario("./output/digital_bin.bin", INSTRUCCIONES_BINARIO)
    guardar_hex("./output/digital_hex.hex", INSTRUCCIONES_BINARIO)
    guardar_cadena_hex("./output/instrucciones_hex.txt", INSTRUCCIONES_BINARIO)
    guardar_instrucciones("./output/instrucciones_BIN_completa.txt", INSTRUCCIONES_BINARIO)

    return INSTRUCCIONES_BINARIO


# =========================
# VALIDACIÓN FINAL
# =========================
archivo = "./output/instrucciones_BIN_completa.txt"
instrucciones_binarias = leer_instrucciones_desde_archivo(archivo)
instrucciones_invalidas = validacion_desde_archivo(instrucciones_binarias)

print(f"Total instrucciones ejecutadas: {len(main('./input/tipob.asm'))}")
print(f"Total inválidas: {len(instrucciones_invalidas)}")
print(f"Tamaño memoria .data: {len(DATA_MEM)} bytes")
