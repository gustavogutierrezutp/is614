from assembler_utilitarios import *

# ==========================================
# INSTRUCCIONES TIPO R
# ==========================================
def inst_r(instruccion: dict, valores, linea=None):
    """
    Ensambla una instrucción tipo R (add, sub, and, or, etc.)
    Formato: funct7 | rs2 | rs1 | funct3 | rd | opcode
    """
    rd = registro(instruccion["rd"], linea)    # registro destino
    rs1 = registro(instruccion["rs1"], linea)  # registro fuente 1
    rs2 = registro(instruccion["rs2"], linea)  # registro fuente 2

    operacion = instruccion.get("operacion")

    funct_3 = valores["inst"][operacion]["funct3"]
    funct_7 = valores["inst"][operacion]["funct7"]
    opcode = valores["opcode"]

    return f"{funct_7}{rs2}{rs1}{funct_3}{rd}{opcode}"


# ==========================================
# INSTRUCCIONES TIPO I
# ==========================================
def inst_i(instruccion: dict, valores, linea=None):
    """
    Ensambla instrucciones tipo I (addi, lw, jalr, etc.)
    Formato general: imm[11:0] | rs1 | funct3 | rd | opcode
    Casos especiales: desplazamientos (slli, srli, srai).
    """
    rd = registro(instruccion["rd"], linea)
    rs1 = registro(instruccion["rs1"], linea)
    raw_imm = instruccion["inm"]

    # validar inmediato
    try:
        imm_val = int(str(raw_imm), 0)  # acepta dec, hex
    except Exception:
        raise ValueError(f"Inmediato inválido: {raw_imm} en línea {linea} -> {instruccion}")

    operacion = instruccion["operacion"]
    funct_3 = valores["inst"][operacion]["funct3"]
    opcode = valores["inst"][operacion]["opcode"]

    # --- CASO 1: instrucciones de desplazamiento ---
    if operacion in ("slli", "srli", "srai"):
        if not (0 <= imm_val <= 31):
            raise ValueError(f"Desplazamiento fuera de rango : {imm_val} en línea {linea} -> {instruccion}")
        cant_desplazar = numero_a_binario(imm_val, 5, con_signo=False)
        funct_7 = valores["inst"][operacion].get("funct7", "0100000" if operacion == "srai" else "0000000")
        return f"{funct_7}{cant_desplazar}{rs1}{funct_3}{rd}{opcode}"

    # --- CASO 2: inmediato general (12 bits con signo) ---
    if not (-2048 <= imm_val <= 2047):
        raise ValueError(f"Inmediato fuera de rango 12 bits: {imm_val} en línea {linea} -> {instruccion}")

    inm_bin = numero_a_binario(imm_val, 12, con_signo=True)
    return f"{inm_bin}{rs1}{funct_3}{rd}{opcode}"


# ==========================================
# INSTRUCCIONES TIPO S
# ==========================================
def inst_s(instruccion: dict, valores, linea=None):
    """
    Ensambla instrucciones tipo S (sw, sh, sb).
    Formato: imm[11:5] | rs2 | rs1 | funct3 | imm[4:0] | opcode
    """
    rs1 = registro(instruccion["rs1"], linea)
    rs2 = registro(instruccion["rs2"], linea)

    raw_imm = instruccion["inm"]
    try:
        imm_val = int(str(raw_imm), 0)
    except Exception:
        raise ValueError(f"Inmediato inválido: {raw_imm} en línea {linea} -> {instruccion}")

    if not (-2048 <= imm_val <= 2047):
        raise ValueError(f"Inmediato fuera de rango 12 bits: {imm_val} en línea {linea} -> {instruccion}")

    inm = numero_a_binario(imm_val, 12, con_signo=True)

    operacion = instruccion["operacion"]
    funct_3 = valores["inst"][operacion]["funct3"]
    opcode = valores["opcode"]

    return f"{inm[0:7]}{rs2}{rs1}{funct_3}{inm[7:]}{opcode}"


# ==========================================
# INSTRUCCIONES TIPO U
# ==========================================
def inst_u(instruccion: dict, valores, linea=None):
    """
    Ensambla instrucciones tipo U (lui, auipc).
    Formato: imm[31:12] | rd | opcode
    """
    raw_inm = instruccion["inm"]
    inm = int(str(raw_inm), 0)  # admite decimal, hex

    # validar rango inmediato U (20 bits con signo)
    if not (-2**19 <= inm <= 2**19 - 1):
        raise ValueError(f"Inmediato fuera de rango 20 bits: {inm} en línea {linea}")

    inm_bin = numero_a_binario(inm, 20, con_signo=True)

    rd = registro(instruccion["rd"], linea)
    operacion = instruccion["operacion"]
    opcode = valores["inst"][operacion]["opcode"]

    return f"{inm_bin}{rd}{opcode}"


# ==========================================
# INSTRUCCIONES TIPO B
# ==========================================
def inst_b(instruccion: dict, valores, linea):
    """
    Ensambla instrucciones tipo B (beq, bne, blt, bge...).
    Formato: imm[12] | inm[10:5] | rs2 | rs1 | funct3 | imm[4:1] | imm[11] | opcode
    """
    rs1 = registro(instruccion["rs1"])
    rs2 = registro(instruccion["rs2"])

    label = instruccion["label"]
    label = distancia_etiqueta(label, linea)  # calcula desplazamiento a la etiqueta
    label = numero_a_binario(label, 13)       # inmediato de 13 bits

    operacion = instruccion["operacion"]
    funct_3 = valores["inst"][operacion]["funct3"]
    opcode = valores["inst"][operacion]["opcode"]

    return f"{label[0]}{label[2:8]}{rs2}{rs1}{funct_3}{label[8:12]}{label[1]}{opcode}"


# ==========================================
# INSTRUCCIONES TIPO J
# ==========================================
def inst_j(instruccion: dict, valores, linea):
    """
    Ensambla instrucciones tipo J (jal).
    Formato: imm[20] | imm[10:1] | imm[11] | imm[19:12] | rd | opcode
    """
    label = instruccion["label"]
    label = distancia_etiqueta(label, linea)  # offset hasta la etiqueta
    label = numero_a_binario(label, 21)       # inmediato de 21 bits

    rd = registro(instruccion["rd"])

    operacion = instruccion["operacion"]
    opcode = valores["inst"][operacion]["opcode"]

    return f"{label[0]}{label[10:20]}{label[9]}{label[1:9]}{rd}{opcode}"
