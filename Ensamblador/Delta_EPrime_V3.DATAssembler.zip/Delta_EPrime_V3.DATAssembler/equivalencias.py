# Define las constantes y variables globales
ARCHIVO_INSTRUCCIONES = "./instrucciones.json"
ARCHIVO_INSTRUCCIONES_PSEUDO = "./pseudoinstrucciones.json"
ETIQUETAS = {}

INSTRUCCIONES_BINARIO = []

Equivalencias = {
    "zero": "x0",    #Registro constante 0
    "ra": "x1",      #Return Address : almacena la dirección de retorno.
    "sp": "x2",      #Stack Pointer : apunta a la cima de la pila. Guarda la dirección del último elemento agregado a la pila.
    "gp": "x3",      #Global Pointer : apunta los datos globales a memoria.
    "tp": "x4",      #Thread Pointer : apunta a la estructura de datos del hilos (contextos de ejecución).
    "t0": "x5",      #Temporal Register 0 : temporal, no se conserva entre llamadas a funciones.
    "t1": "x6",      
    "t2": "x7",     
    "s0": "x8",      #Saved Register 0 : se conserva entre llamadas a funciones.
    "fp": "x8",      #Frame Pointer : apunta al marco de la pila actual
    "s1": "x9",      #Saved Register 1 : se conserva entre llamadas a funciones.
    "a0": "x10",     #Argument Register 0 : para conllevar parámetros a funciones.
    "a1": "x11",     
    "a2": "x12",     
    "a3": "x13",     
    "a4": "x14",     
    "a5": "x15",    
    "a6": "x16",    
    "a7": "x17",    
    "s2": "x18",     
    "s3": "x19",     
    "s4": "x20",     
    "s5": "x21",     
    "s6": "x22",     
    "s7": "x23",    
    "s8": "x24",    
    "s9": "x25",     
    "s10": "x26",    
    "s11": "x27",  
    "t3": "x28",    
    "t4": "x29",     
    "t5": "x30",    
    "t6": "x31",    
}
