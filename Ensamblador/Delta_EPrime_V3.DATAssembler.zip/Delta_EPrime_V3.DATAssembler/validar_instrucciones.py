# Funciones para validación de instrucciones binarias generadas

def leer_instrucciones_desde_archivo(ruta_archivo):
    """
    Lee un archivo de texto que contiene instrucciones binarias (una por línea).
    Retorna una lista de cadenas binarias.
    
    """
    instrucciones_binarias = []
    with open(ruta_archivo, "r") as f:
        for linea in f:
            binario = linea.strip()              # Elimina espacios en blanco o saltos de línea
            instrucciones_binarias.append(binario)
    return instrucciones_binarias


def validacion_desde_archivo(instrucciones_binarias):
    """
    Valida que todas las instrucciones binarias tengan exactamente 32 bits.
    Si encuentra alguna inválida, la muestra por consola e incluye en una lista de inválidas.
    
    """
    invalidas = []
    for i, binario in enumerate(instrucciones_binarias):
        if len(binario) != 32:
            # Se muestra el índice, el contenido y la longitud real de la instrucción inválida
            print(f"Instrucción inválida en índice {i}\nBinario: {binario} Longitud: {len(binario)}")
            invalidas.append(binario)
    return invalidas
