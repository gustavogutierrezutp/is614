import os
from intelhex import IntelHex
from assembler_utilitarios import DATA_MEM  # Importa el buffer de memoria de datos


def guardar_data_bin(nombre_archivo: str):
    """
    Guarda el contenido de la memoria de datos (DATA_MEM) en un archivo binario.
    Cada byte del buffer se escribe directamente en el archivo.
    """
    dirpath = os.path.dirname(nombre_archivo)   # Obtiene el directorio donde se guardará el archivo
    if dirpath:                                 # Si el nombre incluye una ruta de directorio
        os.makedirs(dirpath, exist_ok=True)     # Crea el directorio si no existe
    with open(nombre_archivo, "wb") as f:       # Abre el archivo en modo binario escritura
        f.write(DATA_MEM)                       # Escribe el contenido del buffer DATA_MEM


def guardar_instrucciones(nombre_archivo: str, instrucciones: list):
    """
    Guarda una lista de instrucciones en un archivo de texto plano.
    Cada instrucción se escribe en una línea diferente.
    """
    with open(nombre_archivo, "w") as archivo:
        for instruccion in instrucciones:
            archivo.write(instruccion + "\n")   # Escribe cada instrucción con salto de línea


def guardar_binario(nombre_archivo: str, lista_binaria: list):
    """
    Convierte una lista de cadenas binarias en bytes y los guarda en un archivo binario.
    Cada instrucción (cadena de 32 bits) se divide en bloques de 8 bits (1 byte).
    """
    datos = bytearray()
    for cadena in lista_binaria:
        for i in range(0, len(cadena), 8):       # Procesa la cadena de 8 en 8 bits
            bloque = cadena[i:i+8]              # Extrae un bloque de 8 bits
            numero = int(bloque, 2)             # Convierte el bloque binario en número entero
            datos.append(numero)                # Lo agrega como un byte al arreglo
    
    with open(nombre_archivo, "wb") as archivo:  # Abre el archivo en modo binario
        archivo.write(datos)                     # Escribe los bytes resultantes

def guardar_cadena_binario(nombre_archivo: str, lista_binaria: list):
    with open(nombre_archivo, "w") as archivo:
        for cadena in lista_binaria:
            for i in range(0, len(cadena), 8):
                bloque = cadena[i:i+8]
                archivo.write(bloque + "\n")


def guardar_hex(nombre_archivo: str, lista_binaria: list):
    with open(nombre_archivo, "w") as archivo:
        for cadena in lista_binaria:
            if len(cadena) != 32:
                raise ValueError(f"Instrucción inválida (esperado 32 bits): {cadena}")

            for i in range(0, len(cadena), 8):
                bloque_8_bits = cadena[i:i+8]
                valor_byte = int(bloque_8_bits, 2)
                archivo.write(f"{valor_byte:02X}\n")


def guardar_cadena_hex(nombre_archivo: str, lista_binaria: list):
    with open(nombre_archivo, "w") as archivo:
        for cadena in lista_binaria:
            if len(cadena) != 32:
                raise ValueError(f"Instrucción inválida (esperado 32 bits): {cadena}")

            for i in range(0, len(cadena), 8):
                bloque_8_bits = cadena[i:i+8]
                valor_byte = int(bloque_8_bits, 2)
                archivo.write(f"0x{valor_byte:02X}\n")