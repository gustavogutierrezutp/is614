
Este proyecto es un ensamblador básico, desarrollado en Python, que soporta la arquitectura RISC-V en su subconjunto RV32I. Esta herramienta está diseñada para procesadores con una arquitectura de 32 bits, donde cada registro tiene una longitud de 32 bits, con soporte para: 

* Instrucciones Completas: Soporta las instrucciones base de RISC-V, incluyendo los tipos R, I, S, U y J, cubriendo operaciones aritméticas, lógicas, de desplazamiento, entre otras.

* Pseutoinstrucciones comunes:incluye un archivo json de 23 pseudoinstrucciones comunes como mv, nop, ret, beqz, jal, etc. 

* Maneja los alias de registros, por ejemplo, s0 y fp que se refieren al registro x8.

* Exportacion:permite exportar el código ensamblado a los siguientes formatos: 
    * Binario Puro: Para la interpretación directa en un FPGA.
    * Intel Hex.
    * Archivos .txt: para una fácil lectura de las salidas en formatos anteriores.

Este ensamblador  fue concebido como la primera fase del proyecto final para la asignatura IS614 en la Universidad Tecnológica de Pereira. Bajo la dirección del ingeniero Gustavo Adolfo Gutierrez Sabogal, esta herramienta educativa permite ensamblar instrucciones, verificar errores en tiempo de ensamblado y genera las salidas listas. 

                        CARACTERISTICAS PRINCIPALES

* PARSER basado en expresiones regulares, que reconoce instrucciones y pseudointrucciones.
* Soporta las directivas: 
            - .text : Código ejecutable base.
            - .data : memoria estática inicializada para el manejo de .word , .half y .byte
* Gestión de etiquetas y saltos.
* Validación de errores: 
            - Etiquetas invaladas o repetidas.
            - Registros inexistentes.
            - Inmediatos fuera de rango; los cuales varian segun la intrucciones ejecutada con valores como : 12 bits, 16 bits y 32 bits.
* Directivas .word , .half y .byte definidas incorrectamente.

* Estructura del proyecto:  arquitectura modular - código separado en modulos - del ensamblador:
            - instrucciones.json : definición formal de las instrucciones base.
            - pseudointrucciones.json : definicion de las pseudoinstrucciones.
            - equivalencias.py : alias de los registros y definición de constantes globales.
            - manejador_archivos.py : exportación a .bin, .hex y .txt
            - compilación_instrucciones.py: funciones de compilación de cada tipo de instrucción.
            - assembler_utilitarios.py: utilidades varias empleadas en el archivo principal. 
            - assembler_a_binario.py: segmanetador principal de instrucciones para el ensamblado.

* Ejemplo de Uso: 
program.asm
        .data
        val1:   .word 42
        b1:     .byte -1

        .text   
        main:
            addi sp, sp, -4
            sw   ra, 0(sp)

* Ejecución: 
        python assembler_a_binario.py ./input/program.asm

* Validación de errores comunes: 

- Registro Invalido = ValueError: Registro fuera de rango: x33 - solo x0..x31 - en la línea 2

- Etiqueta no definida o repetida = ValueError: Etiqueta inválida: 'etiqueta9' o duplicada -->línea actual=39  

- Inmediato fuera de rango = ValueError: Inmediato fuera de rango 12 bits: 2048 en línea 3 -> {'operacion': 'addi', 'rd': 'x4', 'rs1': 'x3', 'inm': '2048'}    

- .byte fuera de rango = ValueError: Error en línea 0: valor fuera de rango para .byte Valor recibido: -900, esperado entre -128 y 127

- .word fuera de rango = ValueError: Error en línea 0: valor fuera de rango para .word Valor recibido: -99999999999999, esperado entre -2147483648 y 2147483647

- .half fuera de rango = ValueError: Error en línea 0: valor fuera de rango para .half Valor recibido: 8384767, esperado entre -32768 y 32767


                ARQUITECTURA DE COMPUTADORES 2025II

Estudiantes: 
    * Jorge Luis Araque Gomez.
    * Julián Adolfo Valencia García

Profesor: 
    Gustavo Adolfo Gutierrez Sabogal

Monitor : 
    Amir Evelio Hurtado Mena

Universidad Tecnológica de Pereira (UTP) - Ingenieria en Sistemas y Computación.